# Signal App - Flutter Frontend Setup (Phone Only, No Computer)

## ⚠️ වැදගත් - මුලින්ම මේක කියවන්න

මේ zip එකේ තියෙන්නේ Dart code (`lib/` folder + `pubspec.yaml`) විතරයි. Flutter project එකක් සම්පූර්ණයෙන් build කරන්න `android/` සහ `ios/` folders ඕන (ඒවා auto-generate වෙන්නේ `flutter create` command එකෙන්) - ඒවා මම මෙතන දාලා නෑ, මොකද ඒවා binary/large boilerplate files ගොඩක් තියෙන නිසා. පහත steps වලින් ඒක එකවර විතරක් phone එකෙන්ම හදාගන්න පුළුවන්.

## Step 1: GitHub Repository එකක් හදන්න
1. github.com → New Repository → නමක් දෙන්න (e.g. `signal-app-flutter`)
2. මේ zip එකේ files ඔක්කොම repo එකට upload කරන්න (GitHub web UI eken "Add file" → "Upload files", phone browser eken කරන්න පුළුවන්)

## Step 2: GitHub Codespaces වලින් android/ios folders generate කරන්න (එකවරක් විතරයි)
Codespaces කියන්නේ browser eke open වෙන VS Code එකක් + terminal එකක් - phone එකෙන්ම වැඩ කරන්න පුළුවන්.

1. ඔයාගේ repo එකේ **Code** button → **Codespaces** tab → **Create codespace on main**
2. Codespace එක load වුනාට පස්සේ, terminal එකේ මේවා run කරන්න:
```bash
flutter create --org com.yourcompany --project-name signal_app .
flutter pub get
```
(මේකෙන් `pubspec.yaml`, `lib/` files ඔයාගේ ඒවා preserve වෙනවා, missing `android/`, `ios/` folders විතරක් add වෙනවා)

3. Terminal එකෙන්ම:
```bash
git add .
git commit -m "Add android/ios platform files"
git push
```

## Step 3: GitHub Actions auto-build එක බලන්න
Push කළාට පස්සේ, repo එකේ **Actions** tab එකට යන්න → "Build APK" workflow එක run වෙනවා (minutes 3-5ක් ගන්නවා).
Run එක green tick එකක් වුනාට පස්සේ, ඒ run එක click කරලා → **Artifacts** section → `signal-app-release-apk` download කරගන්න.

## Step 4: APK එක install කරන්න
Download කරගත්ත APK file එක phone එකේ open කරලා install කරන්න ("Install from unknown sources" allow කරන්න ඕන වෙයි Settings වල).

## Step 5: Backend URL configure කරන්න
Push කරන්න කලින් `lib/config/api_config.dart` file එකේ:
```dart
static const String baseUrl = 'https://yourdomain.com/signal-app';
```
මේක ඔයාගේ actual cPanel domain එකට මාරු කරන්න (GitHub web UI eken file එක edit කරලා commit කරන්න පුළුවන්, "pencil" icon eken).

## Google/Apple Sign-In Setup (පස්සේ කරන්න පුළුවන්)
`google_sign_in` සහ `sign_in_with_apple` packages වැඩ කරන්න:
- Google: Firebase Console එකෙන් project එකක් හදලා `google-services.json` file එක `android/app/` folder එකට දාන්න ඕන
- Apple: Apple Developer account එකක් + Sign in with Apple capability enable කරන්න ඕන (iOS build එකට විතරයි අදාළ)

මේ දෙක setup කරන්නත් Codespaces terminal එකෙන්ම කරන්න පුළුවන් - ඕන නම් මට ඊළඟට ඒ steps විස්තර කරන්න පුළුවන්.

## Files Summary
- `lib/config/` — API base URL, colors
- `lib/models/` — Instrument, TradeSignal data models
- `lib/services/` — API calls (auth, signals, coins), local session storage
- `lib/screens/` — Intro, Login, Signup, Forgot Password, Home (coin select), Signal Result, Settings, Change Email
- `lib/widgets/social_sign_in_buttons.dart` — Google + Apple login buttons
- `.github/workflows/build_apk.yml` — auto-builds APK on every push
